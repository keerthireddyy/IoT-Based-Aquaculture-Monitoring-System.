from flask import Flask, render_template, request, flash, redirect
import sqlite3
import pickle
import numpy as np

#from twilio.rest import Client
#account_sid = "AC13b040427ec706a07b2dd9cb2e36a4a1"
#auth_token = "83f6ccd3b2eb4d633fa073d9fb9347db"
#client = Client(account_sid, auth_token)


app = Flask(__name__)
import pickle
rfc=pickle.load(open("rf.pkl","rb"))

def remove_first_decimal(value):
    # Split the number by the decimal point
    parts = value.split('.')

    # Check if there are more than 2 parts (more than one decimal point)
    if len(parts) > 0:
        # Reconstruct the number without the second decimal value
        return parts[0] 
    else:
        # If there's only one or two parts (no second decimal value), return the original value
        return value
    
def remove_second_decimal(value):
    # Split the number by the decimal point
    parts = value.split('.')

    # Check if there are more than 2 parts (more than one decimal point)
    if len(parts) > 2:
        # Reconstruct the number without the second decimal value
        return parts[0] + '.' + parts[1]
    else:
        # If there's only one or two parts (no second decimal value), return the original value
        return value

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/userlog', methods=['GET', 'POST'])
def userlog():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']

        query = "SELECT name, password FROM user WHERE name = '"+name+"' AND password= '"+password+"'"
        cursor.execute(query)

        result = cursor.fetchall()

        if result:
            import requests
            import pandas as pd
            data=requests.get("https://api.thingspeak.com/channels/2484886/feeds.json?api_key=LA2JWE0STU1NZLAB&results=2")
            ph=data.json()['feeds'][-1]['field1']
            temp=data.json()['feeds'][-1]['field2']
            turb=data.json()['feeds'][-1]['field3']
            con=data.json()['feeds'][-1]['field4']

            ph = remove_second_decimal(ph)
            temp = remove_second_decimal(temp)
            turb = remove_second_decimal(turb)
            con = remove_second_decimal(con)
            print(f"pH : {ph} \n temperature : {temp} \n turbidity: {turb} \n conductivity : {con}")
            return render_template('fetal.html',name=name,ph=ph,temp=temp,turb=turb,con=con)
        else:
            return render_template('index.html', msg='Sorry, Incorrect Credentials Provided,  Try Again')

    return render_template('index.html')


@app.route('/userreg', methods=['GET', 'POST'])
def userreg():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        
        print(name, mobile, email, password)

        command = """CREATE TABLE IF NOT EXISTS user(name TEXT, password TEXT, mobile TEXT, email TEXT)"""
        cursor.execute(command)

        cursor.execute("INSERT INTO user VALUES ('"+name+"', '"+password+"', '"+mobile+"', '"+email+"')")
        connection.commit()

        return render_template('index.html', msg='Successfully Registered')
    
    return render_template('index.html')

@app.route('/logout')
def logout():
    return render_template('index.html')


@app.route("/fetalPage", methods=['GET', 'POST'])
def fetalPage():
    import requests
    import pandas as pd
    data=requests.get("https://api.thingspeak.com/channels/2484886/feeds.json?api_key=LA2JWE0STU1NZLAB&results=2")
    ph=data.json()['feeds'][-1]['field1']
    temp=data.json()['feeds'][-1]['field2']
    turb=data.json()['feeds'][-1]['field3']
    con=data.json()['feeds'][-1]['field4']
    ph = remove_second_decimal(ph)
    temp = remove_second_decimal(temp)
    turb = remove_second_decimal(turb)  
    con = remove_second_decimal(con)
    print(f"pH : {ph} \ntemperature : {temp} \n turbidity: {turb} \n conductivity : {con}")
    return render_template('fetal.html',ph=ph,temp=temp,turb=turb,con=con)




@app.route("/predict", methods = ['POST', 'GET'])
def predictPage():
    import requests
    import pandas as pd
    data=requests.get("https://api.thingspeak.com/channels/2484886/feeds.json?api_key=LA2JWE0STU1NZLAB&results=2")
    ph=data.json()['feeds'][-1]['field1']
    tempe=data.json()['feeds'][-1]['field2']
    turb=data.json()['feeds'][-1]['field3']
    con=data.json()['feeds'][-1]['field4']
    ph = remove_second_decimal(ph)
    tempe = remove_second_decimal(tempe)
    turb = remove_first_decimal(turb)  
    con = remove_second_decimal(con)
    print(f"pH : {ph} \ntemperature : {tempe} \n turbidity: {turb} \n conductivity : {con}")
    if request.method == 'POST':
        Conductivity = request.form['Conductivity']
        Turbidity = request.form['Turbidity']
        Temperature = request.form['Temperature']
        Ph = request.form['Ph']
        
        data = np.array([[Turbidity,Conductivity, Temperature, Ph]])
        my_prediction = rfc.predict(data)
        result = my_prediction[0]
        aa=[]
        print(result)

        # Turbidity,Conductivity, Temperature, Ph
        
        
        
        if result == 0 :
            res='in Good Condition '
            #client.api.account.messages.create(
                #to="+91-8431991946",
                #from_="+12566009618",
                #body="Good condotion")



        elif result == 1: 
            res='Not in Good Condition'
            #client.api.account.messages.create(
                #to="+91-8431991946",
                #from_="+12566009618",
                #body="not good condition")
            tur,cond,temp,p="","","",""
            if 7<float(Turbidity)<12:
                tur="High Turbidity"
            if 0<float(Conductivity)<150 or 500<float(Conductivity)<750:
                cond="Current is Passing"
            if 15<float(Temperature)<25 or 27<float(Temperature)<33:
                temp="Not Suitable Temperature"
            if 2<float(Ph)<7 and 9<float(Ph)<14:
                p="Not Suitable pH"
            print("Turbidity {} \n  Conductivity {} \n Temperature {} \n Ph {} \n".format(tur,cond,temp,p))

        
        print(res)

           
        return render_template('predict.html', pred = result,status=res,tur=tur,cond=cond,temp=temp,p=p,ph=ph,tempe=tempe,turb=turb,con=con)
    return render_template('predict.html')

if __name__ == '__main__':
	app.run(debug = True)