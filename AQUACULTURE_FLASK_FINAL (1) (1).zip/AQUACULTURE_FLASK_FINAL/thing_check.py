import requests
import pandas as pd
data=requests.get("https://api.thingspeak.com/channels/2484886/feeds.json?api_key=LA2JWE0STU1NZLAB&results=2")
ph=data.json()['feeds'][-1]['field1']
temp=data.json()['feeds'][-1]['field2']
tur=data.json()['feeds'][-1]['field3']
con=data.json()['feeds'][-1]['field3']
print(f"pH : {ph} \n temperature : {temp} \n turbidity: {tur} \n conductivity : {con}")
